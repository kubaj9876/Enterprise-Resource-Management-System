public enum stanZlecenia {
    Planowane,
    Nieplanowane,
    Realizowane,
    Zakonczone
}
