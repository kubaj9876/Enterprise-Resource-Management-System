public enum rodzajPracy {
    Ogolna,
    Montaz,
    Demontaz,
    Wymiana
}
